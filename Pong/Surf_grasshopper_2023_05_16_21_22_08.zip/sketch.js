
let xBolinha = 300;
let yBolinha = 200;
let diametro = 15;
let raio = diametro / 2;

let velocidadeXBolinha = 8;
let velocidadeYBolinha = 8;
let raqueteComprimento = 10;
let raqueteAltura = 90;

//Variáveis Raquete P1
let xRaquete = 5;
let yRaquete = 150;

//Variáveis Raquete P2
let xRaquete2 = 585;
let yRaquete2 = 150;
let velocidadeYOponente;

//Sons
let hit;
let ponto;
let trilha;

function preload() {
  trilha = loadSound("trilha.mp3");
  ponto = loadSound("ponto.mp3");
  hit = loadSound("raquetada.mp3");
}

let colidiu = false;

//Placar
let meusPontos = 0;
let pontosOponente = 0;

function setup() {
  createCanvas(600, 400);
  trilha.loop();
}

function draw() {
  background(0);
  mostraBolinha();
  movimentaBolinha();
  verificaColisaoBorda();
  mostraRaquete(xRaquete, yRaquete);
  mostraRaquete(xRaquete2, yRaquete2);
  movimentaRaquete();
  //verificaColisaoR();
  colisaoRaqueteBiblioteca(xRaquete, yRaquete);
  colisaoRaqueteBiblioteca(xRaquete2, yRaquete2);
  movimentaRaquete2();
  incluiPlacar();
  marcaPonto();
}

function mostraBolinha() {
  circle(xBolinha, yBolinha, diametro);
}

function movimentaBolinha() {
  xBolinha += velocidadeXBolinha;
  yBolinha += velocidadeYBolinha;
}

function verificaColisaoBorda(){
  if (xBolinha + raio > width || xBolinha - raio < 0) {
    velocidadeXBolinha *= -1;
  }
  
  if (yBolinha + raio > height || yBolinha - raio < 0) {
    velocidadeYBolinha *= -1;
  }
}

function mostraRaquete(x, y) {
  rect(x, y, raqueteComprimento, raqueteAltura);
}

function movimentaRaquete() {
  if (keyIsDown(UP_ARROW)) {
      yRaquete -= 10;
  }
  if (keyIsDown(DOWN_ARROW)) {
      yRaquete += 10;
  }
}

function movimentaRaquete2() {
  if (keyIsDown(87)) {
      yRaquete2 -= 10;
  }
  if (keyIsDown(83)) {
      yRaquete2 += 10;
  }
}

function verificaColisaoR() {
  if (xBolinha - raio < xRaquete + raqueteComprimento &&
     yBolinha - raio < yRaquete + raqueteAltura &&
     yBolinha + raio > yRaquete) {
      velocidadeXBolinha *= -1;
  }
}

function colisaoRaqueteBiblioteca(x, y) {
  colidiu = collideRectCircle(x, y, raqueteComprimento, raqueteAltura, xBolinha, yBolinha, raio);
  if (colidiu) {
    hit.play();
    velocidadeXBolinha *= -1;
  }
}

function incluiPlacar() {
  stroke(255);
  textAlign(CENTER);
  textSize(16);
  fill(color(255, 140, 0));
  rect(150, 10, 40, 20);
  fill(255);
  text(meusPontos, 170, 26);
  fill(color(255, 140, 0));
  rect(450, 10, 40, 20);
  fill(255);
  text(pontosOponente, 470, 26);
}

function marcaPonto() {
  if (xBolinha + raio > width) {
    meusPontos += 1;
    ponto.play();
  }
  if (xBolinha - raio < 0) {
    pontosOponente += 1;
    ponto.play();
  }
}